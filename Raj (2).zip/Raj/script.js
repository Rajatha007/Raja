	// create the module and name it scotchApp
	var myApp = angular.module('myApp', ['ngRoute']);
	

	// configure our routes
	myApp.config(function($routeProvider) {
		$routeProvider

			// route for the add page
			.when('/add', {
				templateUrl : 'pages/add.html',
				controller  : 'mainController'
			})

			// route for the update page
			.when('/update', {
				templateUrl : 'pages/update.html',
				controller  : 'updateController'
			})
			
				// route for the delete page
			.when('/delete', {
				templateUrl : 'pages/delete.html',
				controller  : 'deleteController'
			})

			// route for the view page
			.when('/view', {
				templateUrl : 'pages/view.html',
				controller  : 'viewController'
			});
	});
	
	

	// create the controller and inject Angular's $scope
	myApp.controller('mainController', function($scope) {
	//	create a message to display in our view
	$scope.options = [{ name: "active", id: 1 }, { name: "in-active", id: 2 }];
    $scope.selectedOption = $scope.options[1];
    
    
        $scope.reset = function () {
          $scope.firstName = "";
            $scope.lastName= "";
            $scope.email = "";
        }
        $scope.reset();
        
        $scope.arrayCustomer = [

        ];
        $scope.addCustomer = function() {
        $scope.arrayCustomer.push($scope.firstName);
}
   // $scope.customer.firstName = "";
  //  $scope.customer.email = "";
	});

	myApp.controller('updateController', function($scope) {
		$scope.message = 'This is update.';
	});
	
	myApp.controller('deleteController', function($scope) {
		$scope.message = 'This is delete.';
	});


	myApp.controller('viewController', function($scope) {
	   $scope.names = [
        {name:'Jani',country:'Norway'},
        {name:'Hege',country:'Sweden'},
        {name:'Kai',country:'Denmark'}
    ];
	});